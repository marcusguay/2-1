
import java.util.Scanner;
class D6 {
public static void main(String [] args){
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
}